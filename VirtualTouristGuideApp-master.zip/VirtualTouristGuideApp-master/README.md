# VirtualTouristGuideApp
This is a mobile application which renders information about monument or landmark just by 
taking their live pictures of places and provide all information related to places like
Hospitals , Hotel and Temple and also seek for help in an emergency.

https://user-images.githubusercontent.com/62329643/113416383-d7f34800-93de-11eb-86c5-eb33a732881d.mp4

Features:

1. User can login onto the system, so that the user is uniquely identified.

2. Geo-Tracking Service to provide information about nearby locations.

3. Peaople can promote their business through the app.

4. Social Media Sharing:People can share and flaunt their experiences with their friends on the application.

5. App provide Emergency services.
